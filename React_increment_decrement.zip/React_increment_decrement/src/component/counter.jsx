import React, {Component} from 'react';
class Counter extends Component{
    state={
        count:0
    };
    constructor()
    {
        super();
        this.handleIncrement=this.handleIncrement.bind(this);
        this.handleDecrement=this.handleDecrement.bind(this);
    }
    formatCount()
{
const{count}=this.state;
return count===0? 'zero' :count;
}
handleIncrement()
{
    console.log("Incremented",this);
    this.setState({
        count: this.state.count +1
    })
}
handleDecrement()
{
    console.log("Decremented",this);
    this.setState({
        count: this.state.count -1
    })
}
   
    render()
    {
        let classes="badge m-2 badge-";
        classes+=(this.state.count==0) ? "warning" :"primary";
        return (
        <div>
            
        <span  className={classes}>{this.formatCount()}</span>
            <button onClick ={this.handleIncrement} className="btn btn-success btn-sm">Increment</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button onClick ={this.handleDecrement} className="btn btn-success btn-sm">Decrement</button>
         </div>

        )}
}

export default Counter ;