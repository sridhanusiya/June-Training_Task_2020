import React,{component} from 'react';
class New extends Component{
    render()
    {
    return(
        <p> This is New class</p>
    )
    }
}
export default New;