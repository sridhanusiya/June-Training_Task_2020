import React, { Component } from "react";
import FormContainer from "./FormContainer";

function App() {
  return <FormContainer />;
}
export default App;