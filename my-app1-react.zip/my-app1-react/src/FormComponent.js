import React from "react";
import ReactDOM from 'react-dom';
import App from "./App.css";
function FormComponent(props) {
  function Click() {
    alert("Entered successfully");
  }
  return (
    <main>
      <h1>Form</h1>
      <form className="inputForm">
        <input
          className="text"
          onChange={props.handleChange}
          name="firstName"
          placeholder="First Name"
          value={props.firstName}
        />
        <br />
        <input
          className="text"
          onChange={props.handleChange}
          name="lastName"
          placeholder="Last Name"
          value={props.lastName}
        />
        <br />
           <input
          className="text"
          onChange={props.handleChange}
          name="age"
          placeholder="Age"
          value={props.age}
        />
        <br />
        <br />
    <h3> Gender </h3> <label>
          <input
            className="radiobutton"
            type="radio"
            name="gender"
            value="male"
            checked={props.gender === "male"}
            onChange={props.handleChange}
          />
          Male
        </label>
        <label>
          
          <input
            className="radiobutton"
            type="radio"
            name="gender"
            value="female"
            checked={props.gender === "female"}
            onChange={props.handleChange}
          />
          Female
        </label>
        <br />
        <br/>
        <label className="select" ><h3>Select your band</h3></label>
                <select
          className="select-input"
          onChange={props.handleChange}
          name="selectoption"
          value={props.selectoption}
        >
          <option value="">-- Choose your band --</option>
          <option value="Associate Consultant">Associate Consultant</option>
          <option value="Consultant">Consultant</option>
          <option value="Senior Consultant">Senior Consultant</option>
        </select>
        <br />
        <br />
        <label className="empworkplace"><h3>Work Place</h3></label>
        
        <div className="workplace">
          <input
            type="checkbox"
            name="Offshore"
            onChange={props.handleChange}
            checked={props.Offshore}
          />
          <span>Offshore</span>
          <br />
          <input
            type="checkbox"
            name="Onsite"
            onChange={props.handleChange}
            checked={props.Onsite}
          />
          <span>Onsite</span>
          <br />
         
        </div>
       <br/> 
  <button className="submit" onClick={Click}>Submit</button>
      </form>
      <hr />
      <div className="entered-info">
        <h2>Entered information:</h2>
        <p>
          Your name: {props.firstName} {props.lastName}
        </p>
        <p>Your age: {props.age}</p>
        <p>Your gender: {props.gender}</p>
        <p>Your band :{props.selectoption}</p>
        <p>Employee's Workplace :</p>
        <div className="restrictions">
          <span>Offshore Employee : {props.Offshore ? " Yes" : "No"}</span> <br />
          <span>Onsite Employee : {props.Onsite ? " Yes" : "No"}</span>{" "}
          <br />
         
        </div>
      </div>
    </main>
  );
}


export default FormComponent;
