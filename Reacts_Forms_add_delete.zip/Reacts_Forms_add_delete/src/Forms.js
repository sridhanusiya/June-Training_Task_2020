import React from 'react';


class Forms  extends React.Component {

render(){
      return(
          <div>
        <form onSubmit={this.props.AddRow}>
          <br/>
         Name: <input type='text' name="name"  onChange={this.props.changeInput}/>
      Designation:<input type='text' name="design1" onChange={this.props.changeInput}/>
         Age:<input type='text' type="number" name="age1" onChange={this.props.changeInput}/>
         Gender:<input type='text' type="text" name="gender" onChange={this.props.changeInput}/>
         Years of Exp:<input type='text' type="number" name="yexp" onChange={this.props.changeInput}/>
         <input type="submit" value="Add" />
        </form>
        </div>
      )
      }
}

export default Forms;


