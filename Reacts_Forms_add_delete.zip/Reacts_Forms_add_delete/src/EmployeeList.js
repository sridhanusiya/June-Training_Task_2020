import React from 'react';
import PropTypes from 'prop-types';

class EmployeeList extends React.Component{
    
constructor(props){
    super(props);
       //data=this.props.emp
    }
    
    render()
    {
        const mystyle = {
            color: "white",
            backgroundColor: "DodgerBlue",
            padding: "10px",
            fontFamily: "Arial",
            textAlign : "center"
          };
     
     //   console.log(this.props.rem);
    //    const {data}=this.props.emp;// destructuring
        return(
            <React.Fragment>
            <h1 style={mystyle}>Employee list</h1>
                <table>
                    <TableHead/>
                    <TableBody data={this.props.employees} del={this.props.rem}/>
                </table>
                </React.Fragment>
        );
    }

}
/*
EmployeeList.defaultProps={
  //  name: PropTypes.string.isRequired,

};

EmployeeList.propTypes={
    };
  */  
export default EmployeeList;

const TableHead=()=>{

    return(
                    <thead>
                    <tr>
                        <th>Name</th>&nbsp; &nbsp; &nbsp;
                        <th>Designation</th>&nbsp; &nbsp; &nbsp;
                        <th>Age</th>&nbsp; &nbsp; &nbsp;
                        <th>Gender</th>&nbsp; &nbsp; &nbsp;
                        <th>Years of Experince</th>&nbsp; &nbsp; &nbsp;
                    </tr>
                    </thead>
            );
}
const TableBody=(props)=>{
    console.log(props);
    const tableData=props.data.map(
        (row,index)=>{
            return(  <tr key={index}>
                    <td>{row.empName}</td> &nbsp; &nbsp; &nbsp;                 
                    <td>{row.desig}</td> &nbsp; &nbsp; &nbsp;
                    <td>{row.age}</td> &nbsp; &nbsp; &nbsp;
                    <td>{row.gen}</td> &nbsp; &nbsp; &nbsp;
                    <td>{row.exp}</td> &nbsp; &nbsp; &nbsp; 
                    <td><button onClick={()=>props.del(index)}>delete</button></td>
                </tr>
            )
        })
 
    return    <tbody>{tableData}</tbody>
}